package id.ac.dodledupdup.covid.Adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import id.ac.dodledupdup.covid.Model.RSrujukan.RSrujukanResultItem;
import id.ac.dodledupdup.covid.R;

public class rsRujukanAdapter extends RecyclerView.Adapter<rsRujukanAdapter.ViewHolder> {

    private ArrayList<RSrujukanResultItem> rsItems = new ArrayList<>();
    private Context context;

    public rsRujukanAdapter(Context context){ this.context =context;}

    public void setData(ArrayList<RSrujukanResultItem>items){
        rsItems.clear();
        rsItems.addAll(items);
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public rsRujukanAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list2, parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull rsRujukanAdapter.ViewHolder holder, int position) {
        holder.tvNama.setText(rsItems.get(position).getNama());
        holder.tvALamat.setText(rsItems.get(position).getAlamat());
        holder.btMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String latitude = String.valueOf(rsItems.get(position).getLatitude());
                String longitude = String.valueOf(rsItems.get(position).getLongitude());
                String nama = String.valueOf(rsItems.get(position).getNama());
                Uri gmmIntentUri = Uri.parse("geo:"+latitude+","+longitude+"?q="+nama);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW,gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                context.startActivity(mapIntent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return rsItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNama,tvALamat;
        CardView cvItem;
        Button btMaps;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cvItem = itemView.findViewById(R.id.itemlist2_cv);
            tvNama=itemView.findViewById(R.id.itemlist2_NamaRS);
            tvALamat=itemView.findViewById(R.id.itemlist2_Alamat);
            btMaps= itemView.findViewById(R.id.itemlist2_Button);
        }
    }
}

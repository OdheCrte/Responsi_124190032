package id.ac.dodledupdup.covid.View.Fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import id.ac.dodledupdup.covid.Adapter.kasusAdapter;
import id.ac.dodledupdup.covid.Model.Kasus.ContentItem;
import id.ac.dodledupdup.covid.R;
import id.ac.dodledupdup.covid.View.ViewModel.kasusViewModel;

public class kasusFragment extends Fragment {


    private kasusAdapter kasusAdapter;
    private RecyclerView rvKasus;
    private kasusViewModel kasusViewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_kasus, container, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        kasusAdapter = new kasusAdapter(getContext());
        kasusAdapter.notifyDataSetChanged();

        rvKasus=view.findViewById(R.id.fragmentkasus_rv);
        rvKasus.setLayoutManager(new GridLayoutManager(getContext(), 1));

        kasusViewModel = new ViewModelProvider(this).get(kasusViewModel.class);
       // kasusViewModel.setListKasus();
        //kasusViewModel.getKasus().observe(this,getKasus);

        rvKasus.setAdapter(kasusAdapter);
    }

    private Observer<ArrayList<ContentItem>> getKasus = new Observer<ArrayList<ContentItem>>() {
        @Override
        public void onChanged(ArrayList<ContentItem> contentItems) {
            if (contentItems!=null){
                kasusAdapter.setData(contentItems);
            }
        }
    };
}
package id.ac.dodledupdup.covid.View.ViewModel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

import id.ac.dodledupdup.covid.Model.Kasus.Data;
import id.ac.dodledupdup.covid.Model.Kasus.KasusResponse;
import id.ac.dodledupdup.covid.Service.ApiClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class kasusViewModel extends ViewModel {
    private ApiClient apiClient;
    
    private MutableLiveData<ArrayList<Data>> listKasus= new MutableLiveData<>();
    
    /*public void setListKasus(){
        if(this.apiClient==null){
            apiClient = new ApiClient();
        }
        apiClient.getClient().getKasus().enqueue(new Callback<KasusResponse>() {
            @Override
            public void onResponse(Call<KasusResponse> call, Response<KasusResponse> response) {
                KasusResponse responseKasus = response.body();
                if(responseKasus != null && responseKasus.getData() != null){
                    Data kasusItems = responseKasus.getData();
                    listKasus.postValue(kasusItems);
                }
            }

            @Override
            public void onFailure(Call<KasusResponse> call, Throwable t) {

            }
        });
    }*/
    public LiveData<ArrayList<KasusResponse>>getKasus(){
        ///return listKasus;
        return null;
    }
}

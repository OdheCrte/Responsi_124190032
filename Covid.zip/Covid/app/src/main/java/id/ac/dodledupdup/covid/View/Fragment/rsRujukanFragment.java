package id.ac.dodledupdup.covid.View.Fragment;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import id.ac.dodledupdup.covid.Adapter.rsRujukanAdapter;
import id.ac.dodledupdup.covid.Model.RSrujukan.RSrujukanResultItem;
import id.ac.dodledupdup.covid.R;
import id.ac.dodledupdup.covid.View.ViewModel.rsRujukanViewModel;

public class rsRujukanFragment extends Fragment {

    private rsRujukanAdapter rsAdapter;
    private RecyclerView rvRS;
    private rsRujukanViewModel rsViewModel;

    public rsRujukanFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_rs_rujukan, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rsAdapter = new rsRujukanAdapter(getContext());
        rsAdapter.notifyDataSetChanged();

        rvRS=view.findViewById(R.id.fragmentRSrujukan_rv);
        rvRS.setLayoutManager(new GridLayoutManager(getContext(), 1));

        rsViewModel = new ViewModelProvider(this).get(rsRujukanViewModel.class);
        rsViewModel.setRSrujukan();
        rsViewModel.getRSrujukan().observe(this,getRSrujukan);

        rvRS.setAdapter(rsAdapter);
    }

    private Observer<ArrayList<RSrujukanResultItem>> getRSrujukan = new Observer<ArrayList<RSrujukanResultItem>>() {
        @Override
        public void onChanged(ArrayList<RSrujukanResultItem> rsResultsItems) {
            if (rsResultsItems!=null){
                rsAdapter.setData(rsResultsItems);
            }
        }
    };
}
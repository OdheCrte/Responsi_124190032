package id.ac.dodledupdup.covid.Model.RSrujukan;

import java.util.ArrayList;

public class RSrujukanResponse{
	private int statusCode;
	private ArrayList<RSrujukanResultItem> data;

	public void setStatusCode(int statusCode){
		this.statusCode = statusCode;
	}

	public int getStatusCode(){
		return statusCode;
	}

	public void setData(ArrayList<RSrujukanResultItem> data){
		this.data = data;
	}

	public ArrayList<RSrujukanResultItem> getData(){
		return data;
	}

	@Override
 	public String toString(){
		return 
			"RSrujukanResponse{" + 
			"status_code = '" + statusCode + '\'' + 
			",data = '" + data + '\'' + 
			"}";
		}
}
package id.ac.dodledupdup.covid.Service;

import id.ac.dodledupdup.covid.Model.Kasus.ContentItem;
import id.ac.dodledupdup.covid.Model.Kasus.KasusResponse;
import id.ac.dodledupdup.covid.Model.RSrujukan.RSrujukanResponse;
import retrofit2.Call;
import retrofit2.http.GET;

public interface Service {
    //permintaan untuk menampilkan kasus covid
    @GET("rekapitulasi_v2/jabar/harian")
    Call<ContentItem> getKasus();

    //permintaan untuk menampilkan RS Rujukan covid
    @GET("sebaran_v2/jabar/faskes")
    Call<RSrujukanResponse> getRSrujukan();

}

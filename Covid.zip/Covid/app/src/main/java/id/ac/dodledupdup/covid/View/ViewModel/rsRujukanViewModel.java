package id.ac.dodledupdup.covid.View.ViewModel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

import id.ac.dodledupdup.covid.Model.RSrujukan.RSrujukanResponse;
import id.ac.dodledupdup.covid.Model.RSrujukan.RSrujukanResultItem;
import id.ac.dodledupdup.covid.Service.ApiClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class rsRujukanViewModel extends ViewModel {
    private ApiClient apiClient;

    private MutableLiveData<ArrayList<RSrujukanResultItem>> listRs = new MutableLiveData<>();

    public void setRSrujukan(){
        if(this.apiClient==null){
            apiClient=new ApiClient();
        }

        apiClient.getClient().getRSrujukan().enqueue(new Callback<RSrujukanResponse>() {
            @Override
            public void onResponse(Call<RSrujukanResponse> call, Response<RSrujukanResponse> response) {
                RSrujukanResponse responseRS = response.body();
                if(responseRS != null && responseRS.getData() != null){
                    ArrayList<RSrujukanResultItem> rsRujukanItems = responseRS.getData();
                    listRs.postValue(rsRujukanItems);
                }
            }

            @Override
            public void onFailure(Call<RSrujukanResponse> call, Throwable t) {

            }
        });
    }

    public LiveData<ArrayList<RSrujukanResultItem>> getRSrujukan(){
        return listRs;
    }
}

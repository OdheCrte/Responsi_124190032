package id.ac.dodledupdup.covid.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import id.ac.dodledupdup.covid.Model.Kasus.Data;
import id.ac.dodledupdup.covid.R;

public class kasusAdapter extends RecyclerView.Adapter<kasusAdapter.ViewHolder> {

    private Data kasusItem= new Data();
    private Context context;

    public kasusAdapter(Context context){ this.context=context;}

    public void setData(Data items){
        kasusItem.content.clear();
        kasusItem.content.addAll(items.content);
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public kasusAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list1, parent,false);
        return new kasusAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull kasusAdapter.ViewHolder holder, int position) {
        holder.tvTanggal.setText(kasusItem.content.get(position).getTanggal());
        holder.tvSembuh.setText(kasusItem.content.get(position).getConfirmationSelesai());
        holder.tvMeninggal.setText(kasusItem.content.get(position).getConfirmationMeninggal());
        holder.tvTerkonfirmasi.setText(kasusItem.content.get(position).getConfirmationDiisolasi());
    }

    @Override
    public int getItemCount() {
        return kasusItem.content.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTanggal,tvSembuh,tvMeninggal,tvTerkonfirmasi;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTanggal=itemView.findViewById(R.id.itemlist_tanggal);
            tvSembuh=itemView.findViewById(R.id.itemlist_sembuh);
            tvMeninggal=itemView.findViewById(R.id.itemlist_meninggal);
            tvTerkonfirmasi=itemView.findViewById(R.id.itemlist_terkonfirmasi);
        }
    }
}

package id.ac.dodledupdup.covid.Model.Kasus;

import com.google.gson.annotations.SerializedName;

public class ContentItem{


	@SerializedName("confirmation_diisolasi")
	public int confirmationDiisolasi;

	@SerializedName("confirmation_meninggal")
	public int confirmationMeninggal;

	@SerializedName("confirmation_selesai")
	public int confirmationSelesai;

	@SerializedName("tanggal")
	public String tanggal;



	public void setConfirmationDiisolasi(int confirmationDiisolasi){
		this.confirmationDiisolasi = confirmationDiisolasi;
	}

	public int getConfirmationDiisolasi(){
		return confirmationDiisolasi;
	}

	public void setConfirmationMeninggal(int confirmationMeninggal){
		this.confirmationMeninggal = confirmationMeninggal;
	}

	public int getConfirmationMeninggal(){
		return confirmationMeninggal;
	}

	public void setConfirmationSelesai(int confirmationSelesai){
		this.confirmationSelesai = confirmationSelesai;
	}

	public int getConfirmationSelesai(){
		return confirmationSelesai;
	}

	public void setTanggal(String tanggal){
		this.tanggal = tanggal;
	}

	public String getTanggal(){
		return tanggal;
	}

	@Override
 	public String toString(){
		return 
			"ContentItem{" +
			",confirmation_diisolasi = '" + confirmationDiisolasi + '\'' +
			",confirmation_meninggal = '" + confirmationMeninggal + '\'' +
			",confirmation_selesai = '" + confirmationSelesai + '\'' +
			",tanggal = '" + tanggal + '\'' +
			"}";
		}
}
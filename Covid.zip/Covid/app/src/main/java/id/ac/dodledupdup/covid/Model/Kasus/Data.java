package id.ac.dodledupdup.covid.Model.Kasus;

import java.util.ArrayList;
import com.google.gson.annotations.SerializedName;

public class Data extends ArrayList<Data> {

	@SerializedName("metadata")
	public Metadata metadata;

	@SerializedName("content")
	public ArrayList<ContentItem> content;

	public void setMetadata(Metadata metadata){
		this.metadata = metadata;
	}

	public Metadata getMetadata(){
		return metadata;
	}

	public void setContent(ArrayList<ContentItem> content){
		this.content = content;
	}

	public ArrayList<ContentItem> getContent(){
		return content;
	}

	@Override
 	public String toString(){
		return 
			"Data{" + 
			"metadata = '" + metadata + '\'' + 
			",content = '" + content + '\'' + 
			"}";
		}
}
package id.ac.dodledupdup.covid.Model.Kasus;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class Data {


	@SerializedName("content")
	public List<ContentItem> content;

	public void setContent(List<ContentItem> content){
		this.content = content;
	}

	public List<ContentItem> getContent(){
		return content;
	}

	@Override
 	public String toString(){
		return 
			"Data{" +
			",content = '" + content + '\'' + 
			"}";
		}
}